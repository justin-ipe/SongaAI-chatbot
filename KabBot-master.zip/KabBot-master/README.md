# KabBot
A chat bot to book a ride, estimate fare, look for availability, estimate distance over cab services like UBER and Ola.
